﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StyleCop
{
    class Program
    {
        static void Main(string[] args)
        {
            int c = 0;
            Console.Write("Write a number: ");
            c = Convert.ToInt32(Console.ReadLine());

            ConverityTest converity = new ConverityTest();
            converity.Check(c);

            Console.ReadKey(true);
        }
    }
}
