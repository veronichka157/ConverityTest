﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StyleCop
{
    public class ConverityTest
    {
        public int Check(int a)
        {

            if (a > 5)
            {
                Console.WriteLine("return 1");
                return 1;
            }
            else
            {
                Console.WriteLine("return 10");
                return 10;
            }
        }
    }
}
